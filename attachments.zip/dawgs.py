a=56
b=78
c=3
result=a*b%c
print(result)