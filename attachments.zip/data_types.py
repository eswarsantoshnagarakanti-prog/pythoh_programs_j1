#Datatypes-in python they are 3 data types
#1.int(integer)
#2.str(String)
#3.float(decimals)
name="Hemanth"
age=16
salary=10000.53
data="1234"
print(name)
print(type(name))
print(age)
print(type(age))
print(salary)
print(type(salary))
print(data)
print(type(data))
