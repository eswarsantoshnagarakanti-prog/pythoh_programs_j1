print ("Welcome to pb session")
a=10
b=59
result=a+b
print("Addition of a,b is:",result)