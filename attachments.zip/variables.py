#variables-it is a memory allocation to a value 
name="Hemanth"
age=31
salary=100.00
print(name)
print(age)
print(salary)
